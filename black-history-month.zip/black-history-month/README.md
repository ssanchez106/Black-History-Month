# Black History Month

A Pen created on CodePen.io. Original URL: [https://codepen.io/ssanchez106/pen/oNPxvbG](https://codepen.io/ssanchez106/pen/oNPxvbG).

